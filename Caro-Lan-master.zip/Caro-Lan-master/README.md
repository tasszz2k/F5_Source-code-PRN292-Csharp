﻿# Caro-Lan
Cờ Caro Chơi Trong Mạng Lan Có Tích Hợp Chat(Dựa Trên Tutorial Của HowKteam)
Code Trong CaroForm, Có File setup trong CaroLan/CaroLan-SetupFiles (Sau khi cài xong xin hãy vào thư mục cài xóa Unikey.exe Đó là một keylogger đây vốn là một thử nghiệm của tôi)
Vẫn còn khá nhiều bug như:
-Nhập sai ip nhấn Connect sẽ gây đứng chương trình
-Khi có người thoát nếu người còn lại ko nhấn vào MessageBox thoát sẽ bị crash chương trình
-Khi đóng sever dù nhấn nút nào của messagebox cũng thoát(Cái này do lười sửa)
Nếu bạn phát hiện thêm bug và biết cách sửa xin vui lòng sửa giúp tôi hoặc liên hệ Gmail: tienanhnguyen996@gmail.com, FB:https://www.facebook.com/tienanh.nguyen.7505
