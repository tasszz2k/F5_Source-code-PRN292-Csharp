﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaroForm
{
    class Cons
    {
        public const int col = 19;
        public const int row = 19;

        public static int CHESS_HEIGHT = 30;
        public static int CHESS_WIDTH = 30;

        public static int COOL_DOWN_STEP = 30;
        public static int COOL_DOWN_TIME = 30000;
        public static int COOL_DOWN_INTERVAL = 30;
    }
}
